
function toggleMusic(){
    const music = document.getElementById("bgMusic");
    if(music.paused){ music.play(); }
    else{ music.pause(); }
}

function secretAccess(){
    let code = prompt("Введите код доступа:");
    if(code === "LUX-SS+"){
        window.location.href="secret.html";
    } else{
        alert("Доступ запрещён Архимагом.");
    }
}

function crisisToggle(){
    const prices = document.querySelectorAll(".price");
    prices.forEach(p=>{
        let base = parseInt(p.dataset.base);
        if(p.classList.contains("crisis")){
            p.innerText = base + " Au";
            p.classList.remove("crisis");
        }else{
            let increased = Math.round(base * 1.5);
            p.innerText = increased + " Au (Кризис)";
            p.classList.add("crisis");
        }
    });
}
